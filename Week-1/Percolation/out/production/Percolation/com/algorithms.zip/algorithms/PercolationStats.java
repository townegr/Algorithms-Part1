import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {
    private final int trialCount; // number of computations
    private final double[] results; // percolation threshold results
    private final double mean;
    private final double stddev;
    private final double confidenceLevel;
    private final double confidenceInterval;

    // perform independent trials on an n-by-n grid
    public PercolationStats(int n, int trials) {
        validateArgs(n, trials);
        final int gridSize = n;
        trialCount = trials;
        confidenceLevel = 1.96;
        results = new double[trialCount];

        for (int i = 0; i < trialCount; i++) {
            Percolation p = new Percolation(gridSize);

            while (!p.percolates()) {
                int row = StdRandom.uniform(1, gridSize + 1);
                int col = StdRandom.uniform(1, gridSize + 1);
                p.open(row, col);
            }

            results[i] = p.numberOfOpenSites() / (double) (gridSize * gridSize);
        }

        mean = StdStats.mean(results);
        stddev = StdStats.stddev(results);
        confidenceInterval = confidenceLevel * stddev / Math.sqrt(trialCount);
    }

    // sample mean of percolation threshold
    public double mean() {
        return mean;
    }

    // sample standard deviation of percolation threshold
    public double stddev() {
        return stddev;
    }

    // low endpoint of 95% confidence interval
    public double confidenceLo() {
        return mean() - confidenceInterval();
    }

    // high endpoint of 95% confidence interval
    public double confidenceHi() {
        return mean() + confidenceInterval();
    }

    // test client (see below)
    public static void main(String[] args) {
        int gridSize = Integer.parseInt(args[0]);
        int trialCount = Integer.parseInt(args[1]);

        PercolationStats stats = new PercolationStats(gridSize, trialCount);
        System.out.println("mean                    = " + stats.mean());
        System.out.println("stddev                  = " + stats.stddev());
        System.out.println("95% confidence interval = [" + stats.confidenceLo() + ", " + stats.confidenceHi() + "]");
    }

    private double confidenceInterval() {
        return confidenceInterval;
    }
    private void validateArgs(int n, int trials) {
        if (n <= 0 || trials <= 0) {
            throw new IllegalArgumentException("Both arguments must be greater than 0");
        }
    }
}
